Copy and pastes
BBsig = bbSignalFRA(a,E,pulseParam,M);
        h_mf = matchedfilterMAR(t,pulseParam);
        buffer(1,:) = convContMAR(real(BBsig),h_mf,Tsamp);
        buffer(2,:) = convContMAR(imag(BBsig),h_mf,Tsamp);
        output = buffer(1,:)+(1j*(buffer(2,:)));
        return
        
   
    
    
    %the following step stores the k-th pulse in the k-th row.
    buffer_I(k+1,:) = pulseMAR(t-(k*T),pulseParam);
    %Stores symbol amplitude in-phase buffer
    buffer_I(k+1,:) = real(a(1,k+1)).* buffer_I(k+1,:); 
    if imag(a(1,k+1)) ~= 0;
        %the following step stores the k-th pulse in the k-th row.
        buffer_Q(k+1,:) = pulseMAR(t-(k*T),pulseParam);
        %Stores symbol amplitude in quadrature buffer
        buffer_Q(k+1,:) = imag(a(1,k+1)).* buffer_Q(k+1,:);
    end

%combining in-phase and quadrature signal
bbsignal = B*sum(buffer_I) + (1j*B)*sum(buffer_Q);

%
%







% Example: Given a NRZ signal where:
%                
% a = {+1 or -1}
%                   +N
%                  _____
%                  \       
% bbSignalMAR = B*  \    a[k].p(t-kT),     0 <= k <= N-1 (defined by user)
%                   /                   
%                  /____ 
%                   k=0
%
% For a unit-energy rectangular pulse B = 1/T.
%
% v2: improvements: 
% - B (voltage level in function of E (pulse energy) (assignment 2.1);
% - D and alpha reading (duration of the pulse and rolloff);
% - Buffers I and Q are expanded:
% in order to support first from 0 to 0.5DT and 
% last symbol from (N-1)T + 0.5DT.

    