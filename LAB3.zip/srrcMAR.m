% This function was developed for attendance of the course
% EC4530 - Software Radio
% Assignment: LAB2, section 2.10.
% written by: Marcos Siu (msiu@nps.edu)
%
% Square Root Raised Cosine pulse:
% function p = srrcMAR(t,alpha)
% 
% t = normalized time; (vector [t/T] time/symbolInterval)
% alpha = roll off factor (0<alpha<1)
%
% example:
% t = -2:0.1:2;
% alpha = 0.5;
% p = srrcMAR(t,alpha);
% stem(t,p);

function p = srrcMAR(t,alpha)

% EC4530: Software Radio
% Students: Marcos Siu - msiu@nps.edu
%
% LAB2) Square Root Raised Cosine pulse
% Section: 2.10 Code

%Testing argument alpha:

if alpha == 0;
    alpha = eps;
elseif alpha < 0 | alpha > 1;
    disp('Undefined function for input arguments alpha < 0 or alpha > 1')
    return;
end

% spliting SRRC equation in two pieces (numerator/denominator)
numerator = sin(pi*(1-alpha).*t)+(4*alpha.*t).*cos(pi*(1+alpha).*t);
denominator = (pi.*t).*(1-((4*alpha.*t).^2));

buffer = numerator./denominator;

% eliminating the undefined elements of the vector (NaN)
buffer(t==0) = (1-alpha+(4*alpha/pi));
buffer(abs(t)==abs(0.25/alpha)) = 0.5*alpha*sqrt(2)*((1+(2/pi))*sin(0.25*pi/alpha)+(1-(2/pi))*cos(pi*0.25/alpha));

p = buffer;

return